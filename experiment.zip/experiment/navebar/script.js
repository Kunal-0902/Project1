function openTab(tabName) {
    var i, tabcontent;

    // Hide all tabs
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Show the clicked tab
    document.getElementById(tabName).style.display = "block";

    // Close the navbar on small screens after clicking a tab
    var navbar = document.getElementById("myNavbar");
    if (window.innerWidth <= 600) {
        navbar.classList.remove("responsive");
    }
}

function toggleNavbar() {
    var navbar = document.getElementById("myNavbar");
    navbar.classList.toggle("responsive");
}

// Searchbox
function searchTable() {
    const input = document.getElementById("searchInput");
    const filter = input.value.toLowerCase();
    const rows = document.getElementById("customerData").getElementsByTagName("tr");

    for (let i = 0; i < rows.length; i++) {
        const rowData = rows[i].textContent || rows[i].innerText;
        if (rowData.toLowerCase().includes(filter)) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }
    }
}